﻿' Class filename:       CostOfGoodsSold.vb
' Created/revised by:   <your name> on <current date>

Option Explicit On
Option Strict On
Option Infer Off

Public Class CostOfGoodsSold
    Public BeginValue As Double
    Public PurchaseValue As Double
    Public EndValue As Double
End Class
