﻿' Project name:         Slot Machine Project
' Project purpose:      Simulates a slot machine
' Created/revised by:   <your name> on <current date>

Option Explicit On
Option Infer Off
Option Strict On

Public Class MainForm
    Private Sub clickHereButton_Click(sender As Object, e As EventArgs) Handles clickHereButton.Click
        ' simulates a slot machine


    End Sub

    Private Sub exitButton_Click(sender As Object, e As EventArgs) Handles exitButton.Click
        Me.Close()
    End Sub
End Class
