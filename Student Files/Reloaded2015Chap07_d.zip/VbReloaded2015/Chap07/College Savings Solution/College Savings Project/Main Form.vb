﻿' Project name:         College Savings Project
' Project purpose:      Displays the balance in a savings account
' Created/revised by:   <your name> on <current date>

Option Explicit On
Option Strict On
Option Infer Off

Public Class MainForm
    Private Sub calcButton_Click(sender As Object, e As EventArgs) Handles calcButton.Click
        ' calculate the savings account balance at the end of 18
        ' years, using fixed monthly savings amounts and fixed 
        ' annual interest rates


    End Sub

    Private Sub exitButton_Click(sender As Object, e As EventArgs) Handles exitButton.Click
        Me.Close()
    End Sub
End Class
