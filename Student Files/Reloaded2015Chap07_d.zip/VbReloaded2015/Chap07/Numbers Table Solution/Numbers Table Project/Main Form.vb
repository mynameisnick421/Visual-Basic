﻿' Project name:         Numbers Table Project
' Project purpose:      Display a 4 by 5 table of numbers
' Created/revised by:   <your name> on <current date>

Public Class MainForm
    Private Sub exitButton_Click(sender As Object, e As EventArgs) Handles exitButton.Click
        Me.Close()
    End Sub

End Class
