﻿' Project name:         Property Tax Project
' Project purpose:      Displays the annual property tax
' Created/revised by:   <your name> on <current date>

Public Class MainForm

End Class
