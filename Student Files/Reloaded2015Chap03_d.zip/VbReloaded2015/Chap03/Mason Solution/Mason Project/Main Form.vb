﻿' Project name:         Mason Project
' Project purpose:      Displays the projected sales for each of 3 regions
' Created/revised by:   <your name> on <current date>

Public Class MainForm
    Private Sub exitButton_Click(sender As Object, e As EventArgs) Handles exitButton.Click
        Me.Close()
    End Sub

End Class
