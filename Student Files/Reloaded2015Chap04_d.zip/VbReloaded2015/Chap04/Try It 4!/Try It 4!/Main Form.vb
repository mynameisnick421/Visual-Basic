﻿Option Explicit On
Option Infer Off
Option Strict On

Public Class MainForm
    Private Sub exitButton_Click(sender As Object, e As EventArgs) Handles exitButton.Click
        Me.Close()
    End Sub

    Private Sub displayButton_Click(sender As Object, e As EventArgs) Handles displayButton.Click
        ' concatenates strings

        Dim city As String = "Naperville"
        Dim state As String = "IL"
        Dim rent As Integer = 1385

        ' enter the concatenated strings from Figure 4-13, one at a time, after the = sign
        msgLabel.Text =

    End Sub
End Class
