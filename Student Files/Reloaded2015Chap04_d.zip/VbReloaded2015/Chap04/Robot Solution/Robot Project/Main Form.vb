﻿' Project name:         Robot Project
' Project purpose:      Guess where a robot is hiding
' Created/revised by:   <your name> on <current date>


Public Class MainForm

    ' class-level variable 

    Private Sub exitButton_Click(sender As Object, e As EventArgs) Handles exitButton.Click
        Me.Close()
    End Sub

    Private Sub hideButton_Click(sender As Object, e As EventArgs) Handles hideButton.Click
        ' prepares the interface


    End Sub

    Private Sub door1PictureBox_Click(sender As Object, e As EventArgs) Handles door1PictureBox.Click
        ' displays the appropriate image


    End Sub

    Private Sub door2PictureBox_Click(sender As Object, e As EventArgs) Handles door2PictureBox.Click
        ' displays the appropriate image


    End Sub

    Private Sub door3PictureBox_Click(sender As Object, e As EventArgs) Handles door3PictureBox.Click
        ' displays the appropriate image


    End Sub
End Class
