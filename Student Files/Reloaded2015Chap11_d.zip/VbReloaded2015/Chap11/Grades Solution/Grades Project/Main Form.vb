' Project name:         Grades Project
' Project purpose:      Displays the student's name and grades
' Created/revised by:   <your name> on <current date>

Option Explicit On
Option Strict On
Option Infer Off

Public Class MainForm
    Private Sub exitButton_Click(sender As Object, e As EventArgs) Handles exitButton.Click
        Me.Close()
    End Sub

    Private Sub getButton_Click(sender As Object, e As EventArgs) Handles getButton.Click
        ' gets and displays the name and grades


    End Sub
End Class
