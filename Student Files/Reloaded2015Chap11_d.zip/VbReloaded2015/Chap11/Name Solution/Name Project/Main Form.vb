﻿' Project name:         Name Project
' Project purpose:      Reads the names from a sequential access file and stores the names in an array. 
'                       Sorts the array In descending order And then displays the array contents in a list box.
' Created/revised by:   <your name> on <current date>

Option Explicit On
Option Strict On
Option Infer Off

Public Class MainForm
    Private Sub exitButton_Click(sender As Object, e As EventArgs) Handles exitButton.Click
        Me.Close()
    End Sub

End Class
