﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ex7Button = New System.Windows.Forms.Button()
        Me.ex8Button = New System.Windows.Forms.Button()
        Me.ex6Button = New System.Windows.Forms.Button()
        Me.ex5Button = New System.Windows.Forms.Button()
        Me.ex4Button = New System.Windows.Forms.Button()
        Me.stateTextBox = New System.Windows.Forms.TextBox()
        Me.ex3Button = New System.Windows.Forms.Button()
        Me.ex2Button = New System.Windows.Forms.Button()
        Me.ex1button = New System.Windows.Forms.Button()
        Me.exitButton = New System.Windows.Forms.Button()
        Me.nameTextBox = New System.Windows.Forms.TextBox()
        Me.rateTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rateTextBox)
        Me.GroupBox1.Controls.Add(Me.nameTextBox)
        Me.GroupBox1.Controls.Add(Me.ex7Button)
        Me.GroupBox1.Controls.Add(Me.ex8Button)
        Me.GroupBox1.Controls.Add(Me.ex6Button)
        Me.GroupBox1.Controls.Add(Me.ex5Button)
        Me.GroupBox1.Controls.Add(Me.ex4Button)
        Me.GroupBox1.Controls.Add(Me.stateTextBox)
        Me.GroupBox1.Controls.Add(Me.ex3Button)
        Me.GroupBox1.Controls.Add(Me.ex2Button)
        Me.GroupBox1.Controls.Add(Me.ex1button)
        Me.GroupBox1.Location = New System.Drawing.Point(25, 15)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(250, 289)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Like operator"
        '
        'ex7Button
        '
        Me.ex7Button.Location = New System.Drawing.Point(120, 208)
        Me.ex7Button.Name = "ex7Button"
        Me.ex7Button.Size = New System.Drawing.Size(104, 26)
        Me.ex7Button.TabIndex = 9
        Me.ex7Button.Text = "Example &7"
        Me.ex7Button.UseVisualStyleBackColor = True
        '
        'ex8Button
        '
        Me.ex8Button.Location = New System.Drawing.Point(120, 240)
        Me.ex8Button.Name = "ex8Button"
        Me.ex8Button.Size = New System.Drawing.Size(104, 26)
        Me.ex8Button.TabIndex = 10
        Me.ex8Button.Text = "Example &8"
        Me.ex8Button.UseVisualStyleBackColor = True
        '
        'ex6Button
        '
        Me.ex6Button.Location = New System.Drawing.Point(120, 176)
        Me.ex6Button.Name = "ex6Button"
        Me.ex6Button.Size = New System.Drawing.Size(104, 26)
        Me.ex6Button.TabIndex = 7
        Me.ex6Button.Text = "Example &6"
        Me.ex6Button.UseVisualStyleBackColor = True
        '
        'ex5Button
        '
        Me.ex5Button.Location = New System.Drawing.Point(120, 146)
        Me.ex5Button.Name = "ex5Button"
        Me.ex5Button.Size = New System.Drawing.Size(104, 26)
        Me.ex5Button.TabIndex = 5
        Me.ex5Button.Text = "Example &5"
        Me.ex5Button.UseVisualStyleBackColor = True
        '
        'ex4Button
        '
        Me.ex4Button.Location = New System.Drawing.Point(120, 116)
        Me.ex4Button.Name = "ex4Button"
        Me.ex4Button.Size = New System.Drawing.Size(104, 26)
        Me.ex4Button.TabIndex = 4
        Me.ex4Button.Text = "Example &4"
        Me.ex4Button.UseVisualStyleBackColor = True
        '
        'stateTextBox
        '
        Me.stateTextBox.Location = New System.Drawing.Point(14, 56)
        Me.stateTextBox.Name = "stateTextBox"
        Me.stateTextBox.Size = New System.Drawing.Size(100, 25)
        Me.stateTextBox.TabIndex = 1
        Me.stateTextBox.Text = "stateTextBox"
        '
        'ex3Button
        '
        Me.ex3Button.Location = New System.Drawing.Point(120, 84)
        Me.ex3Button.Name = "ex3Button"
        Me.ex3Button.Size = New System.Drawing.Size(104, 26)
        Me.ex3Button.TabIndex = 3
        Me.ex3Button.Text = "Example &3"
        Me.ex3Button.UseVisualStyleBackColor = True
        '
        'ex2Button
        '
        Me.ex2Button.Location = New System.Drawing.Point(120, 54)
        Me.ex2Button.Name = "ex2Button"
        Me.ex2Button.Size = New System.Drawing.Size(104, 26)
        Me.ex2Button.TabIndex = 2
        Me.ex2Button.Text = "Example &2"
        Me.ex2Button.UseVisualStyleBackColor = True
        '
        'ex1button
        '
        Me.ex1button.Location = New System.Drawing.Point(120, 24)
        Me.ex1button.Name = "ex1button"
        Me.ex1button.Size = New System.Drawing.Size(104, 26)
        Me.ex1button.TabIndex = 0
        Me.ex1button.Text = "Example &1"
        Me.ex1button.UseVisualStyleBackColor = True
        '
        'exitButton
        '
        Me.exitButton.Location = New System.Drawing.Point(200, 330)
        Me.exitButton.Name = "exitButton"
        Me.exitButton.Size = New System.Drawing.Size(75, 26)
        Me.exitButton.TabIndex = 0
        Me.exitButton.Text = "E&xit"
        Me.exitButton.UseVisualStyleBackColor = True
        '
        'nameTextBox
        '
        Me.nameTextBox.Location = New System.Drawing.Point(14, 178)
        Me.nameTextBox.Name = "nameTextBox"
        Me.nameTextBox.Size = New System.Drawing.Size(100, 25)
        Me.nameTextBox.TabIndex = 6
        Me.nameTextBox.Text = "nameTextBox"
        '
        'rateTextBox
        '
        Me.rateTextBox.Location = New System.Drawing.Point(14, 210)
        Me.rateTextBox.Name = "rateTextBox"
        Me.rateTextBox.Size = New System.Drawing.Size(100, 25)
        Me.rateTextBox.TabIndex = 8
        Me.rateTextBox.Text = "rateTextBox"
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(301, 380)
        Me.Controls.Add(Me.exitButton)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Try It 4!"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents ex3Button As System.Windows.Forms.Button
    Friend WithEvents ex2Button As System.Windows.Forms.Button
    Friend WithEvents ex1button As System.Windows.Forms.Button
    Friend WithEvents stateTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ex8Button As System.Windows.Forms.Button
    Friend WithEvents exitButton As System.Windows.Forms.Button
    Friend WithEvents ex7Button As System.Windows.Forms.Button
    Friend WithEvents ex6Button As System.Windows.Forms.Button
    Friend WithEvents ex5Button As System.Windows.Forms.Button
    Friend WithEvents ex4Button As System.Windows.Forms.Button
    Friend WithEvents rateTextBox As System.Windows.Forms.TextBox
    Friend WithEvents nameTextBox As System.Windows.Forms.TextBox

End Class
