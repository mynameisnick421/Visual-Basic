﻿' Project name:         Lucky Project
' Project purpose:      Simulates the Lucky Number Game
' Created/revised by:   <your name> on <current date>

Option Explicit On
Option Strict On
Option Infer Off

Public Class MainForm
    ' declare class-level variable

    Private Sub exitButton_Click(sender As Object, e As EventArgs) Handles exitButton.Click
        Me.Close()
    End Sub

    Private Sub rollButton_Click(sender As Object, e As EventArgs) Handles rollButton.Click
        ' simulates the Lucky Number Game


    End Sub
End Class
