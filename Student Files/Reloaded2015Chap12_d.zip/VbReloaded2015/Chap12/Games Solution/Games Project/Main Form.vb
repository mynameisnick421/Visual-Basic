﻿' Project name:         Games Project
' Project purpose:      Displays all records or only those
'                       for a specific platform. Also displays
'                       the total value of the games in the store.
' Created/revised by:   <your name> on <current date>

Option Explicit On
Option Strict On
Option Infer Off

Public Class MainForm

End Class
