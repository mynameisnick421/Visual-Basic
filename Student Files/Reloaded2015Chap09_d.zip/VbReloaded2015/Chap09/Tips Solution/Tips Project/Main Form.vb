﻿' Project name:         Tips Project
' Project purpose:      Display the average tip
' Created/revised by:   <your name> on <current date>

Public Class MainForm
    Private Sub exitButton_Click(sender As Object, e As EventArgs) Handles exitButton.Click
        Me.Close()
    End Sub

End Class
