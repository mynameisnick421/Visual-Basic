﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.oneLabel = New System.Windows.Forms.Label()
        Me.twoLabel = New System.Windows.Forms.Label()
        Me.threeLabel = New System.Windows.Forms.Label()
        Me.fourLabel = New System.Windows.Forms.Label()
        Me.fiveLabel = New System.Windows.Forms.Label()
        Me.sixLabel = New System.Windows.Forms.Label()
        Me.sevenLabel = New System.Windows.Forms.Label()
        Me.eightLabel = New System.Windows.Forms.Label()
        Me.nineLabel = New System.Windows.Forms.Label()
        Me.displayButton = New System.Windows.Forms.Button()
        Me.exitButton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(34, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(15, 17)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(33, 74)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(15, 17)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "2"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(34, 113)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(15, 17)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "3"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(34, 153)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(15, 17)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "4"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(33, 193)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(15, 17)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "5"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(34, 232)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(15, 17)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = "6"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(33, 272)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(15, 17)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "7"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(33, 312)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(15, 17)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "8"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(34, 351)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(15, 17)
        Me.Label9.TabIndex = 10
        Me.Label9.Text = "9"
        '
        'oneLabel
        '
        Me.oneLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.oneLabel.Location = New System.Drawing.Point(57, 28)
        Me.oneLabel.Name = "oneLabel"
        Me.oneLabel.Size = New System.Drawing.Size(37, 34)
        Me.oneLabel.TabIndex = 11
        Me.oneLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'twoLabel
        '
        Me.twoLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.twoLabel.Location = New System.Drawing.Point(57, 68)
        Me.twoLabel.Name = "twoLabel"
        Me.twoLabel.Size = New System.Drawing.Size(37, 34)
        Me.twoLabel.TabIndex = 12
        Me.twoLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'threeLabel
        '
        Me.threeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.threeLabel.Location = New System.Drawing.Point(57, 108)
        Me.threeLabel.Name = "threeLabel"
        Me.threeLabel.Size = New System.Drawing.Size(37, 34)
        Me.threeLabel.TabIndex = 13
        Me.threeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'fourLabel
        '
        Me.fourLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.fourLabel.Location = New System.Drawing.Point(57, 147)
        Me.fourLabel.Name = "fourLabel"
        Me.fourLabel.Size = New System.Drawing.Size(37, 34)
        Me.fourLabel.TabIndex = 14
        Me.fourLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'fiveLabel
        '
        Me.fiveLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.fiveLabel.Location = New System.Drawing.Point(57, 187)
        Me.fiveLabel.Name = "fiveLabel"
        Me.fiveLabel.Size = New System.Drawing.Size(37, 34)
        Me.fiveLabel.TabIndex = 15
        Me.fiveLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'sixLabel
        '
        Me.sixLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sixLabel.Location = New System.Drawing.Point(57, 227)
        Me.sixLabel.Name = "sixLabel"
        Me.sixLabel.Size = New System.Drawing.Size(37, 34)
        Me.sixLabel.TabIndex = 16
        Me.sixLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'sevenLabel
        '
        Me.sevenLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sevenLabel.Location = New System.Drawing.Point(57, 266)
        Me.sevenLabel.Name = "sevenLabel"
        Me.sevenLabel.Size = New System.Drawing.Size(37, 34)
        Me.sevenLabel.TabIndex = 17
        Me.sevenLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'eightLabel
        '
        Me.eightLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.eightLabel.Location = New System.Drawing.Point(57, 306)
        Me.eightLabel.Name = "eightLabel"
        Me.eightLabel.Size = New System.Drawing.Size(37, 34)
        Me.eightLabel.TabIndex = 18
        Me.eightLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'nineLabel
        '
        Me.nineLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.nineLabel.Location = New System.Drawing.Point(57, 346)
        Me.nineLabel.Name = "nineLabel"
        Me.nineLabel.Size = New System.Drawing.Size(37, 34)
        Me.nineLabel.TabIndex = 19
        Me.nineLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'displayButton
        '
        Me.displayButton.Location = New System.Drawing.Point(135, 28)
        Me.displayButton.Name = "displayButton"
        Me.displayButton.Size = New System.Drawing.Size(80, 41)
        Me.displayButton.TabIndex = 0
        Me.displayButton.Text = "&Display"
        Me.displayButton.UseVisualStyleBackColor = True
        '
        'exitButton
        '
        Me.exitButton.Location = New System.Drawing.Point(135, 76)
        Me.exitButton.Name = "exitButton"
        Me.exitButton.Size = New System.Drawing.Size(80, 41)
        Me.exitButton.TabIndex = 1
        Me.exitButton.Text = "E&xit"
        Me.exitButton.UseVisualStyleBackColor = True
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(256, 408)
        Me.Controls.Add(Me.exitButton)
        Me.Controls.Add(Me.displayButton)
        Me.Controls.Add(Me.nineLabel)
        Me.Controls.Add(Me.eightLabel)
        Me.Controls.Add(Me.sevenLabel)
        Me.Controls.Add(Me.sixLabel)
        Me.Controls.Add(Me.fiveLabel)
        Me.Controls.Add(Me.fourLabel)
        Me.Controls.Add(Me.threeLabel)
        Me.Controls.Add(Me.twoLabel)
        Me.Controls.Add(Me.oneLabel)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(3, 5, 3, 5)
        Me.Name = "MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Count"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents oneLabel As System.Windows.Forms.Label
    Friend WithEvents twoLabel As System.Windows.Forms.Label
    Friend WithEvents threeLabel As System.Windows.Forms.Label
    Friend WithEvents fourLabel As System.Windows.Forms.Label
    Friend WithEvents fiveLabel As System.Windows.Forms.Label
    Friend WithEvents sixLabel As System.Windows.Forms.Label
    Friend WithEvents sevenLabel As System.Windows.Forms.Label
    Friend WithEvents eightLabel As System.Windows.Forms.Label
    Friend WithEvents nineLabel As System.Windows.Forms.Label
    Friend WithEvents displayButton As System.Windows.Forms.Button
    Friend WithEvents exitButton As System.Windows.Forms.Button

End Class
